/*
Name: Lucas Hasting
Course: DA 380
Instructor: Michael Floren
Description: Used to convert long data to wide data 
             (categorical + <data_col> -> split among categories)

Program Parameters: group_by     -> the categorical column
                    grouped_data -> the data column
					output_col   -> column to start storing output,
									will write on columns past this one

Limitations:		output not ordered, can only handel a max of 23 columns
					(does not handel beyond column Z)

Sources:			https://learn.microsoft.com/en-us/javascript/api/office-scripts/excelscript?view=office-scripts
					https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/charCodeAt
					https://www.typescriptlang.org/docs/

Example arguments: group_by="A:A", grouped_data="B:B", output_col="C"
*/

function main(workbook: ExcelScript.Workbook, group_by: string, grouped_data: string, output_col: string) {
	//get the current worksheet
	let selectedSheet = workbook.getActiveWorksheet();

	//get the long data column - only used cells
	let rangeA = selectedSheet.getRange(group_by).getUsedRange();

	//get the wide data column - only used cells
	let rangeB = selectedSheet.getRange(grouped_data).getUsedRange();

	//get the values from long data column, and flatten 2D array
	let old_values = rangeA.getValues();
	let values: string[] = [];

    //for loop used to flatten 2D array
	for (let val of old_values) {
		//ensure val is interpreted as string and add to values array
		values.push(String(val[0]));
	}

	//convert flattened array to set -> unordered collection of unique values
	const unique_values = new Set<string>(values);

	//set the output column
	let letter = output_col;

    //NOTE: sorting can be added by sorting Array.from(unique_values) as desired

	//loop through the set, give it order
	for (let val of Array.from(unique_values)) {
		//filter values based on what is in the set		
		selectedSheet.getAutoFilter().apply(selectedSheet.getRange(group_by).getUsedRange(), 0, { 
			filterOn: ExcelScript.FilterOn.values, 
			values: [val] 
		});

		//get the range of values affected by the filter -> copy filtered data
		let filtered = selectedSheet.getRange(grouped_data).getUsedRange().getSpecialCells(ExcelScript.SpecialCellType.visible);

		//paste the filtered values to output column
		selectedSheet.getRange(letter + "1").copyFrom(filtered, ExcelScript.RangeCopyType.values);

		//set the header of the column to something more meaningful
		selectedSheet.getRange(letter + "1").setValue(
			selectedSheet.getRange(letter + "1").getValue() + "-" + val);

		//increase letter using UTF-16 code - why it does not handel past "Z"
		//NOTE: can be easily modified with a function to handel said cases
		letter = String.fromCharCode(letter.charCodeAt(0) + 1);

		//clear filter
		selectedSheet.getAutoFilter().clearCriteria();
	}
}